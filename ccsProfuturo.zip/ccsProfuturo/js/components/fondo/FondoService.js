"use strict";

//const DATA_ROOT = './data/';

//const FAQS = require(DATA_ROOT + 'faqs.json');

module.exports = {
    fondo: () => {
            return 'Te hemos enviado tu comprobante con éxito';
    }
}
