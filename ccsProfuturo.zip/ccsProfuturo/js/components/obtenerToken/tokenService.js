"use strict";

//const DATA_ROOT = './data/';

//const FAQS = require(DATA_ROOT + 'faqs.json');

module.exports = {
    token: () => {
            return '12345';
    }
}
