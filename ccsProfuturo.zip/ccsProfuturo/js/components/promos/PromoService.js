"use strict";

//const DATA_ROOT = './data/';

//const FAQS = require(DATA_ROOT + 'faqs.json');

module.exports = {
    promo: () => {
            return 'Recuerda participar en la carrera 10K de Profuturo. Más Informes en http://link.com';
    }
}
